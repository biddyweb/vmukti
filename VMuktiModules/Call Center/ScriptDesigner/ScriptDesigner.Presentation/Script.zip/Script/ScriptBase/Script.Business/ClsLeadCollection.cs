using System;
using Script.DataAccess;

namespace Script.Business
{
    public class ClsLeadCollection : ClsBaseCollection<ClsLead>
    {
        public static ClsLeadCollection GetAll(int LeadID,int LeadFieldID)
        {
            ClsLeadCollection obj = new ClsLeadCollection();
            obj.MapObjects(new ClsDynamicScriptDataService().Lead_GetAll(LeadID, LeadFieldID));
            return obj;
        }

        public static int UpdateLeadInfo(int LeadID, int LeadFieldID, string LeadPropertyValue)
        {
            return (new ClsDynamicScriptDataService().UpdateLeadInfo(LeadID, LeadFieldID, LeadPropertyValue));
        }

        public static int UpdateLeadInfo(int LeadID, string StateName, string ZipCode)
        {
            return (new ClsDynamicScriptDataService().UpdateLeadInfo(LeadID, StateName, ZipCode));
        }
    }
}
