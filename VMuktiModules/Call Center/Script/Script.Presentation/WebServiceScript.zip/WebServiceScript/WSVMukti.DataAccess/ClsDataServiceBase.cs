﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using VMuktiAPI;
using System.Configuration;
using WSVMukti.Common;

namespace WSVMukti.DataAccess
{
    public class ClsDataServiceBase
    {

        private bool _isOwner;
        private SqlTransaction _txn;

        public IDbTransaction Txn
        {
            get { return (IDbTransaction)_txn; }
            set { _txn = (SqlTransaction)value; }
        }

        public ClsDataServiceBase()
            : this(null)
        {
        }
        public ClsDataServiceBase(IDbTransaction txn)
        {
            this._isOwner = false;
            try
            {
                if (txn == null)
                {
                    this._isOwner = true;
                }
                else
                {
                    this._txn = (SqlTransaction)txn;
                    this._isOwner = false;
                }
            }
            catch (Exception ex)
            {
                ex.Data.Add("My Key", "VMukti--:--VmuktiModules--:--Call Center--:--Script--:--Script.DataAccess--:--ClsDataServiceBase.cs--:--ClsDataServiceBase()--");
                ClsException.LogError(ex);
                ClsException.WriteToErrorLogFile(ex);
            }
        }
        public static IDbTransaction BeginTransaction()
        {
            SqlConnection txnConnection = new SqlConnection(GetConnectionString());
            txnConnection.Open();
            return txnConnection.BeginTransaction();
        }
        protected object CheckParamValue(DateTime paramValue)
        {
            if (paramValue.Equals(WSVMukti.Common.ClsConstants.NullDateTime))
            {
                return DBNull.Value;
            }
            return paramValue;
        }
        protected object CheckParamValue(decimal paramValue)
        {
            if (paramValue.Equals(WSVMukti.Common.ClsConstants.NullDecimal))
            {
                return DBNull.Value;
            }
            return paramValue;
        }
        protected object CheckParamValue(double paramValue)
        {
            if (paramValue.Equals(WSVMukti.Common.ClsConstants.NullDouble))
            {
                return DBNull.Value;
            }
            return paramValue;
        }
        protected object CheckParamValue(Guid paramValue)
        {
            if (paramValue.Equals(WSVMukti.Common.ClsConstants.NullGuid))
            {
                return DBNull.Value;
            }
            return paramValue;
        }
        protected object CheckParamValue(int paramValue)
        {
            if (paramValue.Equals(WSVMukti.Common.ClsConstants.NullInt))
            {
                return DBNull.Value;
            }
            return paramValue;
        }
        protected object CheckParamValue(float paramValue)
        {
            if (paramValue.Equals(WSVMukti.Common.ClsConstants.NullFloat))
            {
                return DBNull.Value;
            }
            return paramValue;
        }
        protected object CheckParamValue(string paramValue)
        {
            if (string.IsNullOrEmpty(paramValue))
            {
                return DBNull.Value;
            }
            return paramValue;
        }
        protected SqlParameter CreateParameter(string paramName, SqlDbType paramType, ParameterDirection direction)
        {
            SqlParameter returnVal = this.CreateParameter(paramName, paramType, DBNull.Value);
            returnVal.Direction = direction;
            return returnVal;
        }
        protected SqlParameter CreateParameter(string paramName, SqlDbType paramType, object paramValue)
        {
            SqlParameter param = new SqlParameter(paramName, paramType);
            if (paramValue != DBNull.Value)
            {
                switch (paramType)
                {
                    case SqlDbType.Bit:
                        if (paramValue is bool)
                        {
                            paramValue = ((bool)paramValue) ? 1 : 0;
                        }
                        if ((((int)paramValue) < 0) || (((int)paramValue) > 1))
                        {
                            paramValue = WSVMukti.Common.ClsConstants.NullInt;
                        }
                        paramValue = this.CheckParamValue((int)paramValue);
                        break;

                    case SqlDbType.Char:
                    case SqlDbType.NChar:
                    case SqlDbType.NVarChar:
                    case SqlDbType.Text:
                    case SqlDbType.VarChar:
                        paramValue = this.CheckParamValue((string)paramValue);
                        break;

                    case SqlDbType.DateTime:
                        paramValue = this.CheckParamValue((DateTime)paramValue);
                        break;

                    case SqlDbType.Decimal:
                        paramValue = this.CheckParamValue((decimal)paramValue);
                        break;

                    case SqlDbType.Float:
                        paramValue = this.CheckParamValue(Convert.ToSingle(paramValue));
                        break;

                    case SqlDbType.Int:
                        paramValue = this.CheckParamValue((int)paramValue);
                        break;

                    case SqlDbType.UniqueIdentifier:
                        paramValue = this.CheckParamValue(this.GetGuid(paramValue));
                        break;
                }
            }
            param.Value = paramValue;
            return param;
        }
        protected SqlParameter CreateParameter(string paramName, SqlDbType paramType, object paramValue, ParameterDirection direction)
        {
            SqlParameter returnVal = this.CreateParameter(paramName, paramType, paramValue);
            returnVal.Direction = direction;
            return returnVal;
        }
        protected SqlParameter CreateParameter(string paramName, SqlDbType paramType, object paramValue, int size)
        {
            SqlParameter returnVal = this.CreateParameter(paramName, paramType, paramValue);
            returnVal.Size = size;
            return returnVal;
        }
        protected SqlParameter CreateParameter(string paramName, SqlDbType paramType, object paramValue, int size, byte precision)
        {
            SqlParameter returnVal = this.CreateParameter(paramName, paramType, paramValue);
            returnVal.Size = size;
            returnVal.Precision = precision;
            return returnVal;
        }
        protected SqlParameter CreateParameter(string paramName, SqlDbType paramType, object paramValue, int size, ParameterDirection direction)
        {
            SqlParameter returnVal = this.CreateParameter(paramName, paramType, paramValue);
            returnVal.Direction = direction;
            returnVal.Size = size;
            return returnVal;
        }
        protected SqlParameter CreateParameter(string paramName, SqlDbType paramType, object paramValue, int size, byte precision, ParameterDirection direction)
        {
            SqlParameter returnVal = this.CreateParameter(paramName, paramType, paramValue);
            returnVal.Direction = direction;
            returnVal.Size = size;
            returnVal.Precision = precision;
            return returnVal;
        }
        protected DataSet ExecuteDataSet(string cmdText, CommandType cmdType, params IDataParameter[] procParams)
        {
            SqlCommand cmd;
            return this.ExecuteDataSet(out cmd, cmdText, cmdType, procParams);
        }
        protected DataSet ExecuteDataSet(out SqlCommand cmd, string cmdText, CommandType cmdType, params IDataParameter[] procParams)
        {
            SqlConnection cnx = null;
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter();
            cmd = null;
            try
            {
                try
                {
                    cmd = new SqlCommand(cmdText);
                    cmd.CommandType = cmdType;
                    if (procParams != null)
                    {
                        for (int index = 0; index < procParams.Length; index++)
                        {
                            cmd.Parameters.Add(procParams[index]);
                        }
                    }
                    da.SelectCommand = cmd;
                    if (this._isOwner)
                    {
                        cnx = new SqlConnection(GetConnectionString());
                        cmd.Connection = cnx;
                        cnx.Open();
                    }
                    else
                    {
                        cmd.Connection = this._txn.Connection;
                        cmd.Transaction = this._txn;
                    }
                    da.Fill(ds);
                }
                catch
                {
                    throw;
                }
            }
            finally
            {
                if (da != null)
                {
                    da.Dispose();
                }
                if (cmd != null)
                {
                    cmd.Dispose();
                }
                if (this._isOwner)
                {
                    cnx.Dispose();
                }
            }
            return ds;
        }
        protected void ExecuteNonQuery(string procName, params IDataParameter[] procParams)
        {
            SqlCommand cmd;
            this.ExecuteNonQuery(out cmd, procName, procParams);
        }
        protected void ExecuteNonQuery(out SqlCommand cmd, string procName, params IDataParameter[] procParams)
        {
            SqlConnection cnx = null;
            cmd = null;
            try
            {
                try
                {
                    cmd = new SqlCommand(procName);
                    cmd.CommandType = CommandType.StoredProcedure;
                    for (int index = 0; index < procParams.Length; index++)
                    {
                        cmd.Parameters.Add(procParams[index]);
                    }
                    if (this._isOwner)
                    {
                        cnx = new SqlConnection(GetConnectionString());
                        cmd.Connection = cnx;
                        cnx.Open();
                    }
                    else
                    {
                        cmd.Connection = this._txn.Connection;
                        cmd.Transaction = this._txn;
                    }
                    cmd.ExecuteNonQuery();
                }
                catch
                {
                    throw;
                }
            }
            finally
            {
                if (this._isOwner)
                {
                    cnx.Dispose();
                }
                if (cmd != null)
                {
                    cmd.Dispose();
                }
            }
        }
        protected static string GetConnectionString()
        {
            return ConfigurationSettings.AppSettings["ConnectionString"].ToString();
            //return ConfigurationSettings.AppSettings["Data Source=192.168.191.195\\SQLExpress;Initial Catalog=VMukti;User ID=sa;PassWord=mahavir"].ToString();
        }
        protected Guid GetGuid(object value)
        {
            Guid returnVal = WSVMukti.Common.ClsConstants.NullGuid;
            if (value is string)
            {
                return new Guid((string)value);
            }
            if (value is Guid)
            {
                returnVal = (Guid)value;
            }
            return returnVal;
        }
    }
}
