﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml.Linq;
using System.Collections.Generic;
using WSVMukti.Business;

namespace WebServiceScript
{
    /// <summary>
    /// Summary description for Service1
    /// </summary>
    /// 

    //[WebService(Namespace = "http://tempuri.org/")]
    //[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    //[ToolboxItem(false)]


    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]


    internal static class clsStartClass
    {
        // Fields
        //public static int CallID;
        //public static int LeadFieldID;
        //public static int LeadID;
        public static string sCurrentChannelID;
        public static string sCurrentDispositionID;
        //public static string confirmedkey;

        // Methods
        static clsStartClass()
        {
            ;
        }
    }
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1), WebService(Namespace = "http://www.vmukti.com/WebServices/"), ToolboxItem(false)]

    public class clsWSScript : System.Web.Services.WebService
    {
        public static int DispositionID;
        // Methods
        public clsWSScript()
        {
            ;
        }

        [WebMethod]
        public string SaveSelectedOptions(List<int> list, int leadID)
        {
            try
            {
                for (int i = 0; i < list.Count; i++)
                {
                    clsLead.SaveQuestionOptionAnswers(list.ElementAt<int>(i), true, leadID);
                }
                return "Record(s) saved";
            }
            catch (Exception ex)
            {
                if (ex.InnerException == null)
                {
                    return ("Exception: " + ex.Message + ", " + ex.StackTrace);
                }
                return ("Exception: " + ex.Message + ", " + ex.StackTrace + ", " + ex.InnerException.Message + ", " + ex.InnerException.StackTrace);
            }
        }

        [WebMethod]
        public string WSUpdateLeadDetail(int LeadID, string fieldName, string PropertyValue)
        {
            try
            {
                switch (clsLead.UpdateLeadDetailField(LeadID, fieldName, PropertyValue))
                {
                    case 1:
                        return ("Field:" + fieldName + " - Updated Successfully");

                    case -1:
                        return ("Invalid LeadID:" + LeadID);

                    case -2:
                        return ("Invalid FieldName:" + fieldName);

                    case -3:
                        return "Field is either STATE ZIPCODE. Use the methold WSUpdateStateZip() to update these type of fields.";

                    case -4:
                        return "Exception: Unable to update the field";
                }
                return "";
            }
            catch (Exception ex)
            {
                if (ex.InnerException == null)
                {
                    return ("Exception: " + ex.Message + ", " + ex.StackTrace);
                }
                return ("Exception: " + ex.Message + ", " + ex.StackTrace + ", " + ex.InnerException.Message + ", " + ex.InnerException.StackTrace);
            }
        }

        [WebMethod]
        public string WSUpdateStateZip(int LeadID, string StateName, string Zipcode)
        {
            try
            {
                int result = clsLead.UpdateStateZipField(LeadID, StateName, Zipcode);
                if (result > 0)
                {
                    return ("State:" + StateName + ", Zipcode:" + Zipcode + " - Updated Successfully");
                }
                switch (result)
                {
                    case -1:
                        return ("Invalid StateName:" + StateName);

                    case -2:
                        return ("Invalid Zipcode:" + Zipcode);

                    case -3:
                        return "Exception: Unable to update the field";
                }
                return "";
            }
            catch (Exception ex)
            {
                if (ex.InnerException == null)
                {
                    return ("Exception: " + ex.Message + ", " + ex.StackTrace);
                }
                return ("Exception: " + ex.Message + ", " + ex.StackTrace + ", " + ex.InnerException.Message + ", " + ex.InnerException.StackTrace);
            }
        }       

        [WebMethod]
        public int WSAssignDisposition(int LeadID, string DispositionName)
        {
            try
            {
                DispositionID = clsLead.GetDispositionID(DispositionName);
                if (DispositionID != -12)
                {
                    return DispositionID;
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ex)
            {
                return 0;
            }
        }

        [WebMethod]
        public int WSReturnDispositionID(int intitialvalue)
        {
            try
            {
                int TempDispID = DispositionID;
                DispositionID = 0;
                return TempDispID;
            }
            catch (Exception)
            {
                return 0;
            }
        }
    }
}
