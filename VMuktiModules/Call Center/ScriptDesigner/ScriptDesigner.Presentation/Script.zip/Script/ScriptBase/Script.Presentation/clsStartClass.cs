﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Script.Presentation
{
    class clsStartClass
    {
        public static string strStartQuesion = "UserControl14";
        public static string sCurrentChannelID = "";
        public static string sCurrentDispositionID = "";
        public static int LeadID = 1;
        public static int CallID;
        public static string StateName = null;
        public static string ZipCode = null;
        public static string sPhoneNumber = null;
    }
}
