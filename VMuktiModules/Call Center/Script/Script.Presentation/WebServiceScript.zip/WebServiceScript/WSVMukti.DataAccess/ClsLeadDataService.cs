﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace WSVMukti.DataAccess
{
    public class ClsLeadDataService : ClsDataServiceBase
    {
        public int SaveQuestionOptionAnswers(int QueOptionID, bool value, int leadID)
        {
            try
            {
                if (int.Parse(base.ExecuteDataSet(string.Concat(new object[] { "select count(*) from TmpStoreAnswer where QueOptionID=", QueOptionID, " and LeadID=", leadID }), CommandType.Text, null).Tables[0].Rows[0].ItemArray[0].ToString()) < 1)
                {
                    SqlCommand cmd;
                    base.ExecuteNonQuery(out cmd, "spAETmpStoreAnswer", new IDataParameter[] { base.CreateParameter("@pID", SqlDbType.BigInt, -1), base.CreateParameter("@pQueOptionID", SqlDbType.BigInt, QueOptionID), base.CreateParameter("@pValueTF", SqlDbType.BigInt, value), base.CreateParameter("@pLeadID", SqlDbType.BigInt, leadID) });
                    return 1;
                }
                return -1;
            }
            catch (Exception)
            {
                return -3;
            }
        }
        public int UpdateLeadDetailField(int LeadID, string FieldName, string PropertyValue)
        {
            try
            {
                SqlCommand cmd;
                base.ExecuteNonQuery(out cmd, "spWSLeadDetail", new IDataParameter[] { base.CreateParameter("@pLeadID", SqlDbType.Int, LeadID), base.CreateParameter("@pLeadFieldName", SqlDbType.NVarChar, FieldName), base.CreateParameter("@pPropertyValue", SqlDbType.NVarChar, PropertyValue), base.CreateParameter("@pReturnID", SqlDbType.BigInt, ParameterDirection.Output) });
                int ID = int.Parse(cmd.Parameters["@pReturnID"].Value.ToString());
                cmd.Dispose();
                return ID;
            }
            catch (Exception)
            {
                return -4;
            }
        }

        public int UpdateStateZipField(int LeadID, string StateName, string Zipcode)
        {
            try
            {
                SqlCommand cmd;
                base.ExecuteNonQuery(out cmd, "spUWSStateZip", new IDataParameter[] { base.CreateParameter("@pLeadID", SqlDbType.Int, LeadID), base.CreateParameter("@pStateName", SqlDbType.NVarChar, StateName), base.CreateParameter("@pZipcode", SqlDbType.NVarChar, Zipcode), base.CreateParameter("@pReturnID", SqlDbType.BigInt, ParameterDirection.Output) });
                int ID = int.Parse(cmd.Parameters["@pReturnID"].Value.ToString());
                cmd.Dispose();
                return ID;
            }
            catch (Exception)
            {
                return -3;
            }
        }


        public int GetDispositionID(string DispositionName)
        {
            try
            {
                SqlCommand cmd;
                int tempID;
                base.ExecuteNonQuery(out cmd, "spWSWebDispositionID", new IDataParameter[] { base.CreateParameter("@pdispositionName", SqlDbType.NVarChar, DispositionName), base.CreateParameter("@pReturnID", SqlDbType.BigInt, ParameterDirection.Output) }););
                int dispid = int.Parse(cmd.Parameters["@pReturnID"].Value.ToString());
                cmd.Dispose();
                tempID = dispid;
                dispid =0;
                return tempID;
            }
            catch(Exception)
            {
                return -12;
            }
        }
    }
}
