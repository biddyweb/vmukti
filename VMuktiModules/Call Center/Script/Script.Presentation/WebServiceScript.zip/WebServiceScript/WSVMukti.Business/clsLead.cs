﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WSVMukti.DataAccess;
namespace WSVMukti.Business
{
    public class clsLead
    {
        public clsLead()
        {
        }
        public static int SaveQuestionOptionAnswers(int QueOptionID, bool value, int leadID)
        {
            try
            {
                ClsLeadDataService leadData = new ClsLeadDataService();
                return leadData.SaveQuestionOptionAnswers(QueOptionID, value, leadID);
            }
            catch (Exception)
            {
                return -3;
            }

        }
        public static int UpdateLeadDetailField(int LeadID, string FieldName, string PropertyValue)
        {
            try
            {
                ClsLeadDataService leadData = new ClsLeadDataService();
                return leadData.UpdateLeadDetailField(LeadID, FieldName, PropertyValue);
            }
            catch (Exception)
            {
                return -4;
            }

        }
        public static int UpdateStateZipField(int LeadID, string StateName, string Zipcode)
        {
            try
            {
                ClsLeadDataService leadData = new ClsLeadDataService();
                return leadData.UpdateStateZipField(LeadID, StateName, Zipcode);
            }
            catch (Exception)
            {
                return -3;
            }

        }

        public static int GetDispositionID(string DispositionName)
        {
            try
            {
                ClsLeadDataService DispID = new ClsLeadDataService();
                return DispID.GetDispositionID(DispositionName);
            }
            catch (Exception)
            {
                return -7;
            }
        }
        

    }
}
