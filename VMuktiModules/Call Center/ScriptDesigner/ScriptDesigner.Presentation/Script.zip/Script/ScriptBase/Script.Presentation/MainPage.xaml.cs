﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Reflection;

namespace Script.Presentation
{
    public enum ModulePermissions { View = 1 }

    public partial class MainPage : UserControl
    {
        ModulePermissions[] _MyPermissions;
        public static List<Canvas> lstCanvas = new List<Canvas>();

        public MainPage()
        {
            InitializeComponent();
            try
            {
                //_MyPermissions = MyPermissions;
                //FncPermissionsReview();
                VMuktiAPI.VMuktiHelper.RegisterEvent("SetLeadIDScript").VMuktiEvent += new VMuktiAPI.VMuktiEvents.VMuktiEventHandler(Script_VMuktiEvent);
                VMuktiAPI.VMuktiHelper.RegisterEvent("FireNextCallEvent").VMuktiEvent += new VMuktiAPI.VMuktiEvents.VMuktiEventHandler(FireNextCall_VMuktiEvent);

                VMuktiAPI.VMuktiHelper.RegisterEvent("CallThisFunction").VMuktiEvent += new VMuktiAPI.VMuktiEvents.VMuktiEventHandler(MainPage_VMuktiEvent);

                this.Unloaded += new RoutedEventHandler(MainPage_Unloaded);
                
                this.btnEnterDispReason.Click += new RoutedEventHandler(btnEnterDispReason_Click);
                this.btnCancelDispReason.Click += new RoutedEventHandler(btnCancelDispReason_Click);

                this.btnEnterCallBackReason.Click += new RoutedEventHandler(btnEnterCallBackReason_Click);
                this.btnCancelCallBackReason.Click += new RoutedEventHandler(btnCancelCallBackReason_Click);

                this.btnCancelOtherDispReason.Click += new RoutedEventHandler(btnCancelOtherDispReason_Click);
                this.btnEnterOtherDispReason.Click += new RoutedEventHandler(btnEnterOtherDispReason_Click);
                clsStartClass.sCurrentDispositionID = "";
                FncCreateObjects();
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        void btnEnterOtherDispReason_Click(object sender, RoutedEventArgs e)
        {
            cnvDispoButtons.Visibility = Visibility.Visible;
            cnvDispoButtons.IsEnabled = false;
            cnvCallBack.Visibility = Visibility.Hidden;
            cnvOtherDispositon.Visibility = Visibility.Hidden;
            cnvDispositon.Visibility = Visibility.Hidden;
            //blApplicationExit = false;

            VMuktiAPI.VMuktiHelper.CallEvent("SetDisposition", this, new VMuktiAPI.VMuktiEventArgs(int.Parse(clsStartClass.sCurrentDispositionID), txtCallNote.Text, false, null, int.Parse(clsStartClass.sCurrentChannelID)));

            VMuktiAPI.VMuktiHelper.CallEvent("SetDialerEnable", this, new VMuktiAPI.VMuktiEventArgs(true));
            clsStartClass.sCurrentDispositionID = "";
            txtCallNote.Text = string.Empty;
        }

        void btnCancelOtherDispReason_Click(object sender, RoutedEventArgs e)
        {
            //cnvDispositon.Visibility = Visibility.Hidden;
            //cnvCallBack.Visibility = Visibility.Hidden;
            //cnvOtherDispositon.Visibility = Visibility.Hidden;
            //cnvDispoButtons.Visibility = Visibility.Visible;
            //cnvDispoButtons.IsEnabled = true;
            VMuktiAPI.VMuktiHelper.CallEvent("SetLeadIDScript", this, new VMuktiAPI.VMuktiEventArgs(clsStartClass.LeadID));
        }

        void btnCancelCallBackReason_Click(object sender, RoutedEventArgs e)
        {
            //cnvDispositon.Visibility = Visibility.Hidden;
            //cnvCallBack.Visibility = Visibility.Hidden;
            //cnvOtherDispositon.Visibility = Visibility.Hidden;
            //cnvDispoButtons.Visibility = Visibility.Visible;
            //cnvDispoButtons.IsEnabled = true;
            VMuktiAPI.VMuktiHelper.CallEvent("SetLeadIDScript", this, new VMuktiAPI.VMuktiEventArgs(clsStartClass.LeadID));
        }

        void btnEnterCallBackReason_Click(object sender, RoutedEventArgs e)
        {
            if (!CallBackInfoAvailable())
            {
                MessageBox.Show("Fill Proper Values For Call Back");
                return;
            }
            else
            {
                //set callback time
                string sCallBackDateTime = monthPicker.SelectedDate.Value.ToShortDateString();
                sCallBackDateTime += " " + cmbHour.SelectionBoxItem.ToString();
                sCallBackDateTime += ":" + cmbMin.SelectionBoxItem.ToString();
                sCallBackDateTime += ":00";
                sCallBackDateTime += " " + cmbAMPM.SelectionBoxItem.ToString();

                VMuktiAPI.VMuktiHelper.CallEvent("SetDisposition", this, new VMuktiAPI.VMuktiEventArgs(int.Parse(clsStartClass.sCurrentDispositionID), txtCallBackReason.Text, chkIsPublic.IsChecked, sCallBackDateTime, int.Parse(clsStartClass.sCurrentChannelID)));
                VMuktiAPI.VMuktiHelper.CallEvent("SetDialerEnable", this, new VMuktiAPI.VMuktiEventArgs(true));

                cnvDispoButtons.Visibility = Visibility.Visible;
                cnvDispoButtons.IsEnabled = false;
                cnvDispositon.Visibility = Visibility.Hidden;
                cnvCallBack.Visibility = Visibility.Hidden;
                //blApplicationExit = false;
                txtCallBackReason.Text = string.Empty;
                txtCallBackNo.Text = string.Empty;
                chkIsPublic.IsChecked = false;
                monthPicker.SelectedDate.GetValueOrDefault();
                cmbAMPM.SelectedIndex = 0;
                cmbHour.SelectedIndex = 0;
                cmbMin.SelectedIndex = 0;
                clsStartClass.sCurrentDispositionID = "";
            }
        }

        bool CallBackInfoAvailable()
        {
            bool isAllValid = true;
            //if (txtCallBackReason.Text.Trim() == string.Empty)
            //{
            //    isAllValid = false;                
            //}          
            if (cmbMin.SelectedItem == null || cmbHour.SelectedItem == null || cmbAMPM.SelectedItem == null)
            {
                isAllValid = false;
            }
            else if (object.Equals(monthPicker.SelectedDate, null))
            {
                isAllValid = false;
            }
            else if (!object.Equals(monthPicker.SelectedDate, null))
            {
                if (cmbMin.SelectedItem != null && cmbHour.SelectedItem != null && cmbAMPM.SelectedItem != null)
                {
                    string sCallBackDateTime = monthPicker.SelectedDate.Value.ToShortDateString();
                    sCallBackDateTime += " " + cmbHour.SelectionBoxItem.ToString();
                    sCallBackDateTime += ":" + cmbMin.SelectionBoxItem.ToString();
                    sCallBackDateTime += ":00";
                    sCallBackDateTime += " " + cmbAMPM.SelectionBoxItem.ToString();
                    int i = DateTime.Compare(DateTime.Now, DateTime.Parse(sCallBackDateTime));
                    if (i > 0)
                    {
                        isAllValid = false;
                    }
                }
            }
            return isAllValid;

        }

        void btnCancelDispReason_Click(object sender, RoutedEventArgs e)
        {
            //cnvDispositon.Visibility = Visibility.Hidden;
            //cnvCallBack.Visibility = Visibility.Hidden;
            //cnvOtherDispositon.Visibility = Visibility.Hidden;
            //cnvDispoButtons.Visibility = Visibility.Visible;
            //cnvDispoButtons.IsEnabled = true;
            VMuktiAPI.VMuktiHelper.CallEvent("SetLeadIDScript", this, new VMuktiAPI.VMuktiEventArgs(clsStartClass.LeadID));
        }

        void btnEnterDispReason_Click(object sender, RoutedEventArgs e)
        {
            VMuktiAPI.VMuktiHelper.CallEvent("SetDisposition", this, new VMuktiAPI.VMuktiEventArgs(int.Parse(clsStartClass.sCurrentDispositionID), txtDNCReason.Text, true, null, int.Parse(clsStartClass.sCurrentChannelID)));
            VMuktiAPI.VMuktiHelper.CallEvent("SetDialerEnable", this, new VMuktiAPI.VMuktiEventArgs(true));
            cnvDispoButtons.Visibility = Visibility.Visible;
            cnvDispoButtons.IsEnabled = false;
            cnvDispositon.Visibility = Visibility.Hidden;
            cnvCallBack.Visibility = Visibility.Hidden;
            //blApplicationExit = false;
            txtDNCReason.Text = string.Empty;
            txtPhoneNo.Text = string.Empty;
            clsStartClass.sCurrentDispositionID = "";
        }

        void MainPage_VMuktiEvent(object sender, VMuktiAPI.VMuktiEventArgs e)
        {
            for (int i = 0; i < lstCanvas.Count; i++)
            {
                if (lstCanvas[i].Name.ToLower() == e._args[0].ToString().ToLower())
                {
                    cnvMain.Children.Clear();
                    cnvMain.Children.Add(lstCanvas[i]);
                    cnvMain.Visibility = Visibility.Visible;
                    break;
                }
            }
        }

        void FncCreateObjects()
        {
            Type[] typeArr = Assembly.GetAssembly(this.GetType()).GetTypes();

            for (int j = 0; j < typeArr.Length; j++)
            {
                if (typeArr[j].BaseType != null)
                {
                    if (typeArr[j].BaseType.Name.ToLower() == "usercontrol")
                    {
                        //MessageBox.Show(typeArr[j].Name);
                        if (typeArr[j].Name.ToLower() != "mainpage")
                        {
                            Canvas cnv = new Canvas();
                            string[] s = typeArr[j].ToString().Split('.');
                            cnv.Name = typeArr[j].Name;
                            object obj = Activator.CreateInstance(typeArr[j]);
                            cnv.Height = ((UserControl)obj).Height;
                            cnv.Width = ((UserControl)obj).Width;
                            cnv.Children.Add((UIElement)obj);
                            lstCanvas.Add(cnv);
                        }
                    }
                }
            }

            VMuktiAPI.VMuktiHelper.CallEvent("CallThisFunction", this, new VMuktiAPI.VMuktiEventArgs(clsStartClass.strStartQuesion));
        }

        void MainPage_Unloaded(object sender, RoutedEventArgs e)
        {
            //VMuktiAPI.VMuktiHelper.UnRegisterEvent("SetLeadIDScript");
            //VMuktiAPI.VMuktiHelper.UnRegisterEvent("FireNextCallEvent");
            //VMuktiAPI.VMuktiHelper.UnRegisterEvent("CallThisFunction");
            //lstCanvas.Clear();
        }

        public void ClosePod()
        {
            VMuktiAPI.VMuktiHelper.UnRegisterEvent("SetLeadIDScript");
            VMuktiAPI.VMuktiHelper.UnRegisterEvent("FireNextCallEvent");
            VMuktiAPI.VMuktiHelper.UnRegisterEvent("CallThisFunction");
            lstCanvas.Clear();
        }

        void Script_VMuktiEvent(object sender, VMuktiAPI.VMuktiEventArgs e)
        {
            lstCanvas.Clear();
            clsStartClass.LeadID = int.Parse(e._args[0].ToString());
            clsStartClass.sCurrentChannelID = e._args[0].ToString();
            FncCreateObjects();
            //FncVisibility(clsStartClass.strStartQuesion);
        }

        void FireNextCall_VMuktiEvent(object sender, VMuktiAPI.VMuktiEventArgs e)
        {
            VMuktiAPI.VMuktiHelper.CallEvent("SetDispositionButtonClickEvent", this, new VMuktiAPI.VMuktiEventArgs(clsStartClass.sCurrentDispositionID));
        }

        void FncPermissionsReview()
        {
            this.Visibility = Visibility.Hidden;

            for (int i = 0; i < _MyPermissions.Length; i++)
            {
                if (_MyPermissions[i] == ModulePermissions.View)
                {
                    this.Visibility = Visibility.Visible;
                }
            }
        }

        public void SetDispositionCanvas()
        {
            if (clsStartClass.sCurrentDispositionID == "11")
            {
                VMuktiAPI.VMuktiHelper.CallEvent("CallHangUPFromRender", this, new VMuktiAPI.VMuktiEventArgs(true));
                txtPhoneNo.Text = clsStartClass.sPhoneNumber;
                cnvDispositon.Visibility = Visibility.Visible;
                cnvMain.Visibility = Visibility.Hidden;

                cnvDispoButtons.IsEnabled = false;
                cnvDispoButtons.Visibility = Visibility.Hidden;
            }
            else if (clsStartClass.sCurrentDispositionID == "6")
            {
                VMuktiAPI.VMuktiHelper.CallEvent("CallHangUPFromRender", this, new VMuktiAPI.VMuktiEventArgs(true));
                txtCallBackNo.Text = clsStartClass.sPhoneNumber;
                cnvDispoButtons.IsEnabled = false;
                cnvCallBack.Visibility = Visibility.Visible;
                cnvMain.Visibility = Visibility.Hidden;
                cnvOtherDispositon.Visibility = Visibility.Hidden;
                cnvDispoButtons.Visibility = Visibility.Hidden;
            }
            else
            {
                VMuktiAPI.VMuktiHelper.CallEvent("CallHangUPFromRender", this, new VMuktiAPI.VMuktiEventArgs(true));
                txtOtherPhoneNo.Text = clsStartClass.sPhoneNumber;
                cnvDispoButtons.IsEnabled = false;
                cnvCallBack.Visibility = Visibility.Hidden;
                cnvDispositon.Visibility = Visibility.Hidden;
                cnvMain.Visibility = Visibility.Hidden;
                cnvOtherDispositon.Visibility = Visibility.Visible;
                cnvDispoButtons.Visibility = Visibility.Hidden;
            }
        }
    }
}
